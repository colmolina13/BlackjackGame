package cspackage;

public class BlackjackProtocol { //Protocol for blackjack game, handles messages
    private boolean isHost = false;
    private BlackjackGame game = new BlackjackGame();

    public boolean isHost() { //host var
        return isHost;
    }

    public void setHost(boolean isHost) { //sets host
        this.isHost = isHost;
    }

    public void startGame() { //starts the game
        game.startGame();
    }

    public String getGameState() { //getter for game state
        return game.getGameState();
    }

    public Message playerHit() { //player hit
        return new Message(game.playerHit());
    }

    public Message dealerPlay() {
        //only after stand, dealer plays
        return new Message(game.dealerPlay());
    }

    public boolean gameOver() {
        return game.gameOver();
    }

    //Reset the game state
    public void resetGame() {
        game.startGame();
    }
    
    public Message quitGame(String playerName, boolean isHost) {
        if (isHost) {
            //host can stop the game and send everyone back to the lobby
            return new Message(playerName + " (Host) has stopped the game and returned everyone to the lobby.");
        } else {
            //players can only quit the game, but can't send others to the lobby
            return new Message(playerName + " has quit the game.");
        }
    }

    

    public Message processMessage(Message message, String playerName) { //processes important messages, main feature of protocol
        String msgContent = message.getMsg();

        switch (msgContent.toUpperCase()) { //switch case, returns different msg/function depending on the word typed
            case "START":
                if (isHost) {
                    startGame();
                    return new Message("Game has started!\n" + getGameState());
                }
                return new Message("Waiting for the host to start the game.");
            case "HIT":
                return playerHit();
            case "STAND":
                return dealerPlay();
            case "STATE":
                return new Message(getGameState());
            case "QUIT":
            	return quitGame(playerName, isHost);
            case "RESET":
                resetGame();
                return new Message("The game has been reset. Please make your move (HIT, STAND, QUIT):");
            default:
                return new Message("Unknown command.");
        }
    }
}

