package cspackage;

import java.io.*;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;

public class BlackjackMSThread extends Thread {
    private Socket socket;				//private var
    private String clientName = "";
    private static BlackjackProtocol protocol = new BlackjackProtocol(); // Protocol shared by threads
    private boolean isHost = false;
    private static List<BlackjackMSThread> players = new ArrayList<>();	//List of players
    
    private ObjectOutputStream out; // Output stream for sending data
    private ObjectInputStream in;   // Input stream for receiving data

    public BlackjackMSThread(Socket socket) {
        super("BlackjackMSThread");
        this.socket = socket;
    }

    public void run() {
        try {
            in = new ObjectInputStream(socket.getInputStream());
            out = new ObjectOutputStream(socket.getOutputStream());	// Initialize input and output streams
            out.flush();

            synchronized (players) {
                players.add(this);  //add this thread to the player list
            }

            //send welcome message and request player name
            out.writeObject(new Message("Welcome to Blackjack! Please enter your name: "));
            out.flush();
            
            Message clientMessage = (Message) in.readObject(); //wait for player's name
            clientName = clientMessage.getMsg();
            System.out.println("Client connected: " + clientName);
            
            //for version 1, player will always be host
            isHost = true;

            //Send host message to player; for now, always host
            if (isHost) {
                out.writeObject(new Message("You are the host. Waiting for others to join. To start, type START. To quit, type QUIT."));
            } else {
                out.writeObject(new Message("You are a player. Waiting for the host to start the game."));
            }

            // Wait for host to start the game
            while (true) {
                clientMessage = (Message) in.readObject();
                String clientText = clientMessage.getMsg();

                if ("START".equalsIgnoreCase(clientText) && isHost) {
                    synchronized (protocol) {
                        protocol.startGame();  // Start the game via BlackjackProtocol
                    }
                    broadcastGameState("Game has started! " + protocol.getGameState());	//initial game state
                    break;
                } else if ("QUIT".equalsIgnoreCase(clientText)) {
                    out.writeObject(new Message("You quit the game."));
                    out.flush(); 	//game is quit, client ends
                    break;
                } else if ("START".equalsIgnoreCase(clientText)) {
                    out.writeObject(new Message("Waiting for the host to start the game..."));
                    out.flush();	//not host, can't start game
                }
                else {
                	out.writeObject(new Message("Unknown command."));
                	out.flush();
                }
            }

            // Main game loop
            while (true) {
                clientMessage = (Message) in.readObject();
                String clientText = clientMessage.getMsg();

                if ("QUIT".equalsIgnoreCase(clientText)) {
                    out.writeObject(new Message("You quit the game."));
                    out.flush();	//quit ends client if not host

                    synchronized (protocol) {
                        broadcastGameState(protocol.quitGame(clientName, isHost).getMsg()); //host can send back to lobby
                    }

                    //Player is removed from game for now, will have to be changed in updated version where there is host and players
                    synchronized (players) {
                        players.remove(this);
                    }
                    break;
                }

                
                //reset logic
                if ("RESET".equalsIgnoreCase(clientText) && isHost) {
                    synchronized (protocol) {
                        protocol.resetGame();  //reset the game state via BlackjackProtocol
                    }
                    //broadcast game state after reset
                    broadcastGameState("The game has been reset.\n" + protocol.getGameState());
                    continue;
                }


                //process normal actions (HIT, STAND, etc.) via BlackjackProtocol
                Message response;
                synchronized (protocol) {
                    response = protocol.processMessage(clientMessage, clientName);  //protocol handles messages
                }

                // If the response is valid, send it back to the player
                if (response != null) {
                    out.writeObject(response);
                    out.flush();
                }
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    /**sendGameStateToClient() client receives game state, used in broadcast message
     * Preconditions: state is not null, game in progress
     * @param state of the game
     */
    public void sendGameStateToClient(String state) {
        try {
            out.writeObject(new Message(state));
            out.flush();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //sends out the game state
    public static void broadcastGameState(String state) {
        synchronized (players) {
            for (BlackjackMSThread player : players) {
                player.sendGameStateToClient(state);
            }
        }
    }
}
