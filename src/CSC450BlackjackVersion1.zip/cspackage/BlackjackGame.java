package cspackage;

import java.util.*;

public class BlackjackGame { //Actual blackjack game logic
    private final List<Integer> playerHand = new ArrayList<>();
    private final List<Integer> dealerHand = new ArrayList<>();
    private Integer playerHiddenCard;
    private Integer dealerHiddenCard;
    private final Random rand = new Random();
    private boolean revealHiddenCards = false;

    /**startGame() - starts game
     * Preconditions: playerHand and dealerHand are non-null and clear, drawCard() returns a card, 4 cards available
     * Postconditions: player/dealerHand contain a card that can be seen, revealHiddenCards is false, 4 cards drawn
     * 
     */    
    public void startGame() { // 
        playerHand.clear();
        dealerHand.clear();
        revealHiddenCards = false;

        playerHiddenCard = drawCard();
        dealerHiddenCard = drawCard();

        playerHand.add(drawCard());  // visible
        dealerHand.add(drawCard());  // visible
    }

    
    //card drawer
    private int drawCard() {
        return rand.nextInt(10) + 1;
    }

    /**    
     * 
     *  Preconditions: hand, hiddenCard are not null with valid values
     * @return total value of hand
     */
    
    private int handTotal(List<Integer> hand, Integer hiddenCard) {
        int total = 0;
        for (int card : hand) total += card;
        if (hiddenCard != null) total += hiddenCard;
        return total;
    }

    /** Preconditions: playerHand and dealerHand contains valid values
     * @return string value containing game state (player hand, total, dealers hand)
     */
    public String getGameState() {
        StringBuilder sb = new StringBuilder();

        if (revealHiddenCards) {
            // Show full hands
            List<Integer> fullPlayerHand = new ArrayList<>(playerHand);
            fullPlayerHand.add(playerHiddenCard);
            List<Integer> fullDealerHand = new ArrayList<>(dealerHand);
            fullDealerHand.add(dealerHiddenCard);

            sb.append("Your hand: ").append(playerHand).append(", ").append(playerHiddenCard).append("\n");
            sb.append("Total: ").append(handTotal(playerHand, playerHiddenCard)).append("\n");
            sb.append("Dealer hand: ").append(fullDealerHand).append(" (total: ").append(handTotal(dealerHand, dealerHiddenCard)).append(")\n");
        } else {
            sb.append("Your hand: ").append(playerHand).append(", [Hidden]\n");
            sb.append("Total: ").append(handTotal(playerHand, null)).append(" + ?\n");
            sb.append("Dealer shows: ").append(dealerHand.get(0)).append(", [Hidden]");
        }

        return sb.toString();
    }


    /**
     * Preconditions: playerHand is valid, drawCard, getWinner and getGameState exists 
     * @return New card to player's hand
     */
    public String playerHit() {
        playerHand.add(drawCard());
        int total = handTotal(playerHand, playerHiddenCard);
        
        if (total > 21) {
            revealHiddenCards = true;
            return getWinner(); //if the player busts, the winner is named and cards revealed
        }

        return getGameState(); //otherwise, game state is returned
    }


    public String playerStand() { //stand option, just reveals cards, dealer will play their turn
        revealHiddenCards = true;
        return dealerPlay();
    }

    /**
     * dealerPlay() - dealer plays their turn
     * Preconditions: dealerHand and dealerHiddenCard are valid values, getGameState and getWinner exist
     * @return gameState is dealer busts, getWinner if both players are under or equal to 21
     */
    public String dealerPlay() {
        // Dealer hits until reaching 17 or more
        while (handTotal(dealerHand, dealerHiddenCard) <= 17) {
            dealerHand.add(drawCard());
        }

        // Check if the dealer busted
        if (handTotal(dealerHand, dealerHiddenCard) > 21) {
            return getGameState() + "\nDealer busted! You win!";
        }

        //Compare hands
        return getWinner();
    }

    
    /**getWinner() - retrieves the winner of the game and how they won
     * Preconditions: All player and dealer hands/cards are valid
     * The game is at a state where hidden cards are revealed
     * @return String with player's and dealer's full hands
     * Correct message for the outcome of the game
     */
    private String getWinner() {
        int playerTotal = handTotal(playerHand, playerHiddenCard); //totals of the hands
        int dealerTotal = handTotal(dealerHand, dealerHiddenCard);

        List<Integer> fullPlayerHand = new ArrayList<>(playerHand);
        fullPlayerHand.add(playerHiddenCard);	//combine player hand and hidden cards

        List<Integer> fullDealerHand = new ArrayList<>(dealerHand);
        fullDealerHand.add(dealerHiddenCard);	//same for dealer

        StringBuilder sb = new StringBuilder();
        sb.append("Your hand: ").append(fullPlayerHand).append(" (total: ").append(playerTotal).append(")\n");
        sb.append("Dealer's hand: ").append(fullDealerHand).append(" (total: ").append(dealerTotal).append(")\n"); //show hands
        							
        if (playerTotal > 21) {
            sb.append("You busted! Dealer wins!");
        } else if (dealerTotal > 21 || playerTotal > dealerTotal) {
            sb.append("You win!");
        } else if (playerTotal == dealerTotal) {
            sb.append("It's a tie!");
        } else {
            sb.append("Dealer wins!");
        } //Game outcome messages

        return sb.toString();
    }



    public boolean isPlayerBusted() {  //logic for checking if player busted
        return handTotal(playerHand, playerHiddenCard) > 21;
    }

    public boolean gameOver() {   //logic for deciding if game should end
        return isPlayerBusted() || revealHiddenCards;
    }
}

